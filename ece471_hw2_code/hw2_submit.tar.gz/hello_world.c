#include <stdio.h>

int main(int argc, char **argv) {

	for(int i=0;i<15;i++){
	printf("#%d: ECE471 This is awesome \n",i);

	}

	printf("\n");
	return 0;
}
