#define SENSOR_NAME "/sys/bus/w1/devices/28-0416565043ff/w1_slave"
